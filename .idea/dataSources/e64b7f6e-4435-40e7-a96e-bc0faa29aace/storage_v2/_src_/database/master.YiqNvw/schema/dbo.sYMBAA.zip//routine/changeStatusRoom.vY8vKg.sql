


-- Procudure change status room
CREATE PROC changeStatusRoom @roomName VARCHAR(15), @status VARCHAR(120) AS
    UPDATE Room SET roomStatus = @status WHERE roomName = @roomName
go

