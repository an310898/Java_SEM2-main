CREATE PROC checkIsManager @username VARCHAR(15), @position VARCHAR(30) AS
    SELECT * FROM Account AC WHERE AC.username = @username AND AC.position = @position
go

