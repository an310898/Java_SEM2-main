CREATE PROC addUsedService @checkinID INT, @serviceID INT, @serviceQty INT AS
    INSERT INTO usedServices(checkinID, usedServiceID, usedServiceQty) VALUES (@checkinID, @serviceID, @serviceQty)
go

